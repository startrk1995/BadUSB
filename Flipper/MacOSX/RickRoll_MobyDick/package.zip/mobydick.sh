moby="$(curl -s https://raw.githubusercontent.com/GITenberg/Moby-Dick--Or-The-Whale_2701/master/2701-0.txt | tail -n +850)";say Moby Dick by Herman Melville;sleep 1;echo $moby | say
